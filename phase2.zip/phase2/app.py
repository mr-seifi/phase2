import os
from fetcher import FetchService
from flask import Flask
from cache_service import RedisClient
from dotenv import load_dotenv


app = Flask(__name__)
load_dotenv()


@app.route('/price/<string:ticker>/')
def price(ticker: str):

    key_expiration = int(os.getenv('KEY_EXP'))
    fetch_service = FetchService()
    cache_service = RedisClient(key_expiration)

    cached_price = cache_service.get_price(ticker)
    if cached_price:
        return {
            'pair': f'{ticker.lower()}usdt',
            'price': cached_price
        }

    current_price = fetch_service.fetch_price(ticker)
    cache_service.cache_price(ticker, current_price)

    return {
        'pair': f'{ticker.lower()}usdt',
        'price': float(current_price)
    }


if __name__ == "__main__":
    port = os.getenv('PORT')
    app.run(host="0.0.0.0", port=port, debug=True)
