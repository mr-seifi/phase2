from redis import Redis


class RedisClient:

    def __init__(self, ex: int):
        self._ex = ex

    @property
    def client(self):
        return Redis('redis')

    def cache_price(self, ticker, price):
        return self.client.set(f'{ticker}_price', price, ex=self._ex)

    def get_price(self, ticker):
        return float((self.client.get(f'{ticker}_price') or b'0').decode())
