import requests


class FetchService:

    def __init__(self) -> None:
        self._base_url = 'https://api.kucoin.com'

    def fetch_price(self, ticker: str):
        endpoint = 'api/v1/prices'

        return requests.get(
            f'{self._base_url}/{endpoint}').json().get('data').get(ticker.upper())
